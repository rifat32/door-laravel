<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\UserRequest;
use App\Http\Requests\UserUpdateRequest;
use Illuminate\Http\Request;
use App\Http\Services\UserServices;

class UserController extends Controller
{
    use UserServices;
    public function createUser(UserRequest $request)
    {
        return $this->createUserService($request);
    }
    public function updateUser(UserUpdateRequest $request)
    {
        return $this->updateUserService($request);
    }

    public function getUsers(Request $request)
    {
        return $this->getUsersService($request);
    }
    public function deleteUser(Request $request, $id)
    {
        return $this->deleteUserService($request, $id);
    }
    public function searchUser(Request $request, $term)
    {
        return $this->searchUserService($term,$request);
    }

}
