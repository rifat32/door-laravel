<?php

return [
    "roles_permission" => [
        [
            "role" => "system user",
            "permissions" => [
                "create product"

            ],
        ],


    ],
    "roles" => [
        "system user",
        "trader",
        "customer",


    ],
    "permissions" => [
      "create product"



    ],

];
