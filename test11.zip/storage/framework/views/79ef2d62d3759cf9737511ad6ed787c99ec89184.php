<?php
require_once("../vendor/autoload.php");
$succespage = "https://door-next.vercel.app/other/order-completed";
$cancelpage = "https://localhost.sharedwithexpose.com/paymentcancel";
\Stripe\Stripe::setApiKey("sk_test_51Kdy9JE00LZ83RrlSJYCuLu7imUQTeGTUbTgxfAx1lpsVhiPcxcYcegCSGyUW9UY0PdzukNxesWQyCTbK9EFHOWk000bHfgH9O");

$session = \Stripe\Checkout\Session::create([
    'line_items' => [[
        'price_data' => [
            'currency' => 'eur',
            'product_data' => [
                'name' => 'Ashford Door',

            ],
            'unit_amount' => 20 * 100,
        ],
        'quantity' =>2,
    ]],
    'mode' => 'payment',
    'success_url' => $succespage,
    'cancel_url' => $cancelpage,
]);


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <title>Checkout</title>
    <script src="https://js.stripe.com/v3/"></script>
</head>


<body>

</body>
<script>
    const stripe = Stripe('pk_test_51Kdy9JE00LZ83RrliVhubgDL8Xo5QCAFAOUVNRMUvDjBcWjM6KGcfZzFLVjHK8PTlR0vXUiFBRKuft89GkazPCVb00pfF2yZeV') //Your Publishable key.
    stripe.redirectToCheckout({
        sessionId: "<?php echo $session->id ?> "
    })
    const btn = document.getElementById('checkout-button');
    btn.addEventListener("click", function(e) {
        e.preventDefault();

    })

</script>

</html>
<?php /**PATH /home/rifat/door-laravel-main/resources/views/checkout.blade.php ENDPATH**/ ?>